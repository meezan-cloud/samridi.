
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useLanguage } from '@/context/LanguageContext';

const AboutPage = () => {
  const { t } = useLanguage();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold text-samriddhi-purple mb-6">
            {t('nav.about')}
          </h1>
          <p className="mb-6 text-gray-700">
            Samriddhi Yuva is a career guidance platform dedicated to empowering rural youth in North Karnataka. 
            Our mission is to bridge the information gap and provide accessible career resources to students who have completed 
            10th grade, PUC, or ITI.
          </p>
          <p className="text-gray-700">
            Through personalized guidance, local opportunity awareness, and skill development resources, 
            we help young people discover and pursue fulfilling career paths.
          </p>
          
          {/* Placeholder content */}
          <div className="mt-8 p-6 bg-gray-100 rounded-lg border border-gray-200">
            <p className="text-gray-600 italic">More detailed information about Samriddhi Yuva will be available soon.</p>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AboutPage;
