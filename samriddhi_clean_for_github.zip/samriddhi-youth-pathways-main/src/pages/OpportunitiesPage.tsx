
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const OpportunitiesPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold text-samriddhi-purple mb-6">
            Opportunities
          </h1>
          <p className="mb-6 text-gray-700">
            Discover job opportunities, internships, and training programs that match your skills and interests.
          </p>
          
          {/* Placeholder content */}
          <div className="mt-8 p-6 bg-gray-100 rounded-lg border border-gray-200">
            <p className="text-gray-600 italic">Opportunities listings will be available soon.</p>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default OpportunitiesPage;
