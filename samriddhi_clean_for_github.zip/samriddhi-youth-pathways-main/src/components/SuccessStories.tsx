
import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

// Sample success stories data
const successStoriesData = [
  {
    id: '1',
    name: 'Ramesh Kumar',
    title: 'From Village School to Software Engineer',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGluZGlhbiUyMG1hbnxlbnwwfHwwfHx8MA%3D%3D',
    quote: 'Career guidance opened doors I never knew existed.',
    description: 'After completing his 10th grade in a small village school, Ramesh discovered his passion for programming through a career workshop. With guidance and determination, he pursued computer science education and now works at a leading tech company.',
  },
  {
    id: '2',
    name: 'Priya Sharma',
    title: 'Rural Entrepreneur Success',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW5kaWFuJTIwd29tYW58ZW58MHx8MHx8fDA%3D',
    quote: 'Understanding local opportunities transformed my future.',
    description: 'Priya started a small agricultural processing business after ITI training in food technology. Her company now employs 15 people from her village and supplies products to major retailers.',
  },
  {
    id: '3',
    name: 'Arjun Patil',
    title: 'From ITI to Manufacturing Leader',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8aW5kaWFuJTIwbWFufGVufDB8fDB8fHww',
    quote: 'Technical skills changed my life trajectory.',
    description: 'After completing his ITI in mechanical engineering, Arjun joined an automotive manufacturing company. With dedicated upskilling, he rose to become a production supervisor leading a team of 30 workers.',
  },
  {
    id: '4',
    name: 'Lakshmi Devi',
    title: 'Healthcare Hero from Rural Beginnings',
    image: 'https://images.unsplash.com/photo-1584516150909-8dcbd5eb2159?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8aW5kaWFuJTIwbnVyc2V8ZW58MHx8MHx8fDA%3D',
    quote: 'Education is the pathway to serving my community.',
    description: 'Lakshmi pursued nursing after her PUC when a career counselor highlighted the growing healthcare sector. Today, she works at a district hospital and runs health awareness camps in villages.',
  },
  {
    id: '5',
    name: 'Vijay Naik',
    title: 'Agricultural Innovation Champion',
    image: 'https://images.unsplash.com/photo-1512485694743-9c9538b4e6e0?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8aW5kaWFuJTIwbWFufGVufDB8fDB8fHww',
    quote: 'Modern farming techniques transformed my family business.',
    description: 'Vijay combined traditional farming knowledge with modern agricultural techniques learned through specialized programs. His farm now serves as a model for sustainable practices in his region.',
  },
  {
    id: '6',
    name: 'Meena Kulkarni',
    title: 'Digital Marketing Specialist',
    image: 'https://images.unsplash.com/photo-1546961329-78bef0414d7c?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGluZGlhbiUyMHdvbWFufGVufDB8fDB8fHww',
    quote: 'Learning digital skills opened global opportunities.',
    description: 'After PUC, Meena discovered digital marketing through a career workshop. She took online courses while working part-time, and now manages social media for international clients from her hometown.',
  },
  {
    id: '7',
    name: 'Suresh Reddy',
    title: 'From 10th Grade to Skilled Electrician',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGluZGlhbiUyMG1hbnxlbnwwfHwwfHx8MA%3D%3D',
    quote: 'Vocational training was my perfect path.',
    description: 'Suresh chose electrical training after 10th grade. After completing his certification, he worked for contractors before starting his own electrical services business, which now employs five other electricians.',
  }
];

export default function SuccessStories() {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [expandedStory, setExpandedStory] = useState<string | null>(null);
  
  const storiesPerView = 3;
  const totalPages = Math.ceil(successStoriesData.length / storiesPerView);
  
  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex + storiesPerView >= successStoriesData.length 
        ? 0 
        : prevIndex + storiesPerView
    );
  };
  
  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex - storiesPerView < 0 
        ? Math.max(0, successStoriesData.length - storiesPerView) 
        : prevIndex - storiesPerView
    );
  };
  
  const toggleExpandStory = (id: string) => {
    setExpandedStory(expandedStory === id ? null : id);
  };
  
  const visibleStories = successStoriesData.slice(
    currentIndex,
    currentIndex + storiesPerView
  );
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold text-samriddhi-purple mb-2">
            {t('stories.title')}
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('stories.subtitle')}
          </p>
        </div>
        
        <div className="relative">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {visibleStories.map((story) => (
              <div 
                key={story.id} 
                className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={story.image} 
                    alt={story.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{story.name}</h3>
                  <h4 className="text-samriddhi-purple mb-2">{story.title}</h4>
                  
                  <p className="text-gray-600 italic mb-3">"{story.quote}"</p>
                  
                  <div className={`overflow-hidden transition-all duration-300 ${
                    expandedStory === story.id ? 'max-h-96' : 'max-h-16'
                  }`}>
                    <p className="text-gray-600">{story.description}</p>
                  </div>
                  
                  <button
                    onClick={() => toggleExpandStory(story.id)}
                    className="mt-4 text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors text-sm flex items-center"
                  >
                    {expandedStory === story.id ? 'Show Less' : t('stories.readMore')}
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          {/* Navigation controls */}
          {totalPages > 1 && (
            <div className="flex justify-center mt-8 space-x-4">
              <button 
                onClick={prevSlide} 
                className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors"
              >
                <ChevronLeft size={24} className="text-samriddhi-purple" />
              </button>
              
              <div className="flex items-center space-x-2">
                {Array.from({ length: totalPages }).map((_, i) => (
                  <span 
                    key={i}
                    className={`h-2 w-2 rounded-full ${
                      Math.floor(currentIndex / storiesPerView) === i 
                        ? 'bg-samriddhi-purple' 
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
              
              <button 
                onClick={nextSlide} 
                className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors"
              >
                <ChevronRight size={24} className="text-samriddhi-purple" />
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
