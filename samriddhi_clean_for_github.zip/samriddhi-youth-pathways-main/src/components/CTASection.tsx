
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';

export default function CTASection() {
  const { t } = useLanguage();
  
  return (
    <section className="py-16 bg-samriddhi-orange">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
          Ready to Begin Your Career Journey?
        </h2>
        <p className="text-xl text-white/90 max-w-2xl mx-auto mb-8">
          Take the first step towards a brighter future. Our personalized guidance will help you discover the right path.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/onboarding"
            className="px-8 py-3 bg-white text-samriddhi-orange rounded-md font-medium text-lg hover:bg-opacity-90 transition-all transform hover:scale-105"
          >
            {t('hero.cta')}
          </Link>
          <Link
            to="/resources"
            className="px-8 py-3 border-2 border-white text-white rounded-md font-medium text-lg hover:bg-white/10 transition-all"
          >
            Explore Resources
          </Link>
        </div>
      </div>
    </section>
  );
}
