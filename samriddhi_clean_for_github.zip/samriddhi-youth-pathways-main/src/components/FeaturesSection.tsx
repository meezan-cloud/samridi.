
import { BookOpen, Briefcase, Users, Award } from 'lucide-react';

const features = [
  {
    title: 'Career Guidance',
    description: 'Get personalized advice from experts to choose the right career path based on your interests and strengths',
    icon: <BookOpen className="h-12 w-12 text-samriddhi-purple" />,
  },
  {
    title: 'Job Opportunities',
    description: 'Access to local job listings, internships, and training programs tailored to your skills and location',
    icon: <Briefcase className="h-12 w-12 text-samriddhi-orange" />,
  },
  {
    title: 'Community Support',
    description: 'Connect with mentors and peers who can guide you through your career journey and provide support',
    icon: <Users className="h-12 w-12 text-samriddhi-blue" />,
  },
  {
    title: 'Skill Development',
    description: 'Resources and programs to help you develop essential skills for your chosen career path',
    icon: <Award className="h-12 w-12 text-samriddhi-green" />,
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-samriddhi-purple mb-2">How We Help You Succeed</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Our platform offers various resources and tools designed to support your career journey</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-all card-hover"
            >
              <div className="mb-4 flex justify-center">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center">{feature.title}</h3>
              <p className="text-gray-600 text-center">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
