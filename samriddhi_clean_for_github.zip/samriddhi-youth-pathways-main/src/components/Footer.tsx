
import { Link } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';

export default function Footer() {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-samriddhi-purple text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <img 
              src="/lovable-uploads/7fd6e0f8-2002-4f33-9d56-fa7cdcaebe5f.png" 
              alt="Samriddhi Yuva Logo" 
              className="h-12 w-auto mb-4 bg-white p-1 rounded"
            />
            <p className="text-sm text-gray-200">
              Samriddhi Yuva - Guiding rural youth toward successful careers through education and opportunities.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-200 hover:text-white transition-colors">
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-200 hover:text-white transition-colors">
                  {t('nav.about')}
                </Link>
              </li>
              <li>
                <Link to="/resources" className="text-gray-200 hover:text-white transition-colors">
                  {t('nav.resources')}
                </Link>
              </li>
              <li>
                <Link to="/opportunities" className="text-gray-200 hover:text-white transition-colors">
                  {t('nav.opportunities')}
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">{t('footer.contact')}</h3>
            <address className="not-italic text-sm text-gray-200">
              <p className="mb-2">Email: contact@samriddhiyuva.org</p>
              <p className="mb-2">Phone: +91 1234567890</p>
              <p>Bangalore, Karnataka, India</p>
            </address>
          </div>
        </div>
        
        <div className="border-t border-gray-600 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-300">
            &copy; {currentYear} Samriddhi Yuva. {t('footer.rights')}
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link to="/privacy" className="text-sm text-gray-300 hover:text-white transition-colors">
              {t('footer.privacy')}
            </Link>
            <Link to="/terms" className="text-sm text-gray-300 hover:text-white transition-colors">
              {t('footer.terms')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
