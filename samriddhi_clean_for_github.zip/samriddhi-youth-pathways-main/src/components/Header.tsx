
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t } = useLanguage();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          <Link to="/" className="flex items-center space-x-2">
            <img 
              src="/lovable-uploads/7fd6e0f8-2002-4f33-9d56-fa7cdcaebe5f.png" 
              alt="Samriddhi Yuva Logo" 
              className="h-10 w-auto"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors">
              {t('nav.home')}
            </Link>
            <Link to="/about" className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors">
              {t('nav.about')}
            </Link>
            <Link to="/resources" className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors">
              {t('nav.resources')}
            </Link>
            <Link to="/opportunities" className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors">
              {t('nav.opportunities')}
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <LanguageSwitcher />
            <Link 
              to="/profile" 
              className="bg-samriddhi-purple text-white px-4 py-2 rounded-md hover:bg-opacity-90 transition-all"
            >
              {t('nav.profile')}
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <LanguageSwitcher />
            <button onClick={toggleMenu} className="ml-4 text-samriddhi-purple">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t animate-fade-in">
          <div className="container mx-auto px-4 py-2">
            <nav className="flex flex-col space-y-3 py-4">
              <Link 
                to="/" 
                className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                {t('nav.home')}
              </Link>
              <Link 
                to="/about" 
                className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                {t('nav.about')}
              </Link>
              <Link 
                to="/resources" 
                className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                {t('nav.resources')}
              </Link>
              <Link 
                to="/opportunities" 
                className="text-samriddhi-purple hover:text-samriddhi-orange font-medium transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                {t('nav.opportunities')}
              </Link>
              <Link 
                to="/profile" 
                className="bg-samriddhi-purple text-white px-4 py-2 rounded-md hover:bg-opacity-90 transition-all inline-block w-full text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                {t('nav.profile')}
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
