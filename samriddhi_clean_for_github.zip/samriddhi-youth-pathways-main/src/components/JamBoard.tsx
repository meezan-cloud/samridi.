
import { useState } from 'react';
import { PlusCircle, X, Briefcase, BookOpen, Code, Paintbrush, Leaf, HeartPulse } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

// Default interest icons mapped by category
const interestIcons: Record<string, React.ReactNode> = {
  "technology": <Code className="h-8 w-8 text-samriddhi-blue" />,
  "education": <BookOpen className="h-8 w-8 text-samriddhi-green" />,
  "business": <Briefcase className="h-8 w-8 text-samriddhi-orange" />,
  "arts": <Paintbrush className="h-8 w-8 text-samriddhi-red" />,
  "agriculture": <Leaf className="h-8 w-8 text-samriddhi-green" />,
  "healthcare": <HeartPulse className="h-8 w-8 text-samriddhi-red" />,
  "default": <Briefcase className="h-8 w-8 text-samriddhi-blue" />,
};

interface Interest {
  id: string;
  title: string;
  description: string;
  category: string;
}

export default function JamBoard() {
  const { t } = useLanguage();
  const [interests, setInterests] = useState<Interest[]>([
    {
      id: '1',
      title: 'Web Development',
      description: 'Building websites and web applications',
      category: 'technology',
    },
    {
      id: '2',
      title: 'Teaching',
      description: 'Educating the next generation',
      category: 'education',
    },
    {
      id: '3',
      title: 'Entrepreneurship',
      description: 'Starting and growing businesses',
      category: 'business',
    },
  ]);

  const [isAdding, setIsAdding] = useState(false);
  const [newInterest, setNewInterest] = useState({
    title: '',
    description: '',
    category: 'default',
  });

  const handleAddInterest = () => {
    if (newInterest.title.trim() && newInterest.description.trim()) {
      const id = Date.now().toString();
      setInterests([...interests, { id, ...newInterest }]);
      setNewInterest({ title: '', description: '', category: 'default' });
      setIsAdding(false);
    }
  };

  const handleRemoveInterest = (id: string) => {
    setInterests(interests.filter((interest) => interest.id !== id));
  };

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold text-samriddhi-purple mb-2">{t('jamboard.title')}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{t('jamboard.subtitle')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Interest cards */}
          {interests.map((interest) => (
            <div 
              key={interest.id}
              className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg animate-scale-in"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-gray-100 rounded-full">
                  {interestIcons[interest.category] || interestIcons.default}
                </div>
                <button 
                  onClick={() => handleRemoveInterest(interest.id)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              <h3 className="text-xl font-semibold mb-2">{interest.title}</h3>
              <p className="text-gray-600">{interest.description}</p>
            </div>
          ))}

          {/* Add Interest Card */}
          {!isAdding ? (
            <button
              onClick={() => setIsAdding(true)}
              className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center min-h-[200px] hover:border-samriddhi-purple transition-colors text-gray-500 hover:text-samriddhi-purple"
            >
              <PlusCircle size={40} className="mb-4" />
              <span className="font-medium">{t('jamboard.addInterest')}</span>
            </button>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold">{t('jamboard.addInterest')}</h3>
                <button 
                  onClick={() => setIsAdding(false)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder={t('jamboard.placeholderTitle')}
                    className="w-full px-3 py-2 border rounded-md"
                    value={newInterest.title}
                    onChange={(e) => setNewInterest({ ...newInterest, title: e.target.value })}
                  />
                </div>
                <div>
                  <textarea
                    placeholder={t('jamboard.placeholderDesc')}
                    className="w-full px-3 py-2 border rounded-md"
                    rows={3}
                    value={newInterest.description}
                    onChange={(e) => setNewInterest({ ...newInterest, description: e.target.value })}
                  />
                </div>
                <div>
                  <select 
                    className="w-full px-3 py-2 border rounded-md"
                    value={newInterest.category}
                    onChange={(e) => setNewInterest({ ...newInterest, category: e.target.value })}
                  >
                    <option value="default">General</option>
                    <option value="technology">Technology</option>
                    <option value="education">Education</option>
                    <option value="business">Business</option>
                    <option value="arts">Arts</option>
                    <option value="agriculture">Agriculture</option>
                    <option value="healthcare">Healthcare</option>
                  </select>
                </div>
                <div className="flex justify-end space-x-2">
                  <button 
                    onClick={() => setIsAdding(false)} 
                    className="px-4 py-2 border rounded-md"
                  >
                    {t('jamboard.cancel')}
                  </button>
                  <button 
                    onClick={handleAddInterest} 
                    className="px-4 py-2 bg-samriddhi-purple text-white rounded-md hover:bg-opacity-90"
                  >
                    {t('jamboard.save')}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
