
interface TranslationDictionary {
  [key: string]: string;
}

interface Translations {
  [language: string]: TranslationDictionary;
}

const translations: Translations = {
  en: {
    // Header
    "nav.home": "Home",
    "nav.about": "About",
    "nav.resources": "Resources",
    "nav.opportunities": "Opportunities",
    "nav.profile": "Profile",
    
    // Landing Page
    "hero.title": "Discover Your Career Path",
    "hero.subtitle": "Guidance, resources, and opportunities for your future",
    "hero.cta": "Get Started",
    
    // Success Stories
    "stories.title": "Success Stories",
    "stories.subtitle": "Real stories from people like you who achieved their goals",
    "stories.readMore": "Read More",
    
    // JamBoard
    "jamboard.title": "Express Your Interests",
    "jamboard.subtitle": "Add skills and interests to get personalized recommendations",
    "jamboard.addInterest": "Add Interest",
    "jamboard.placeholderTitle": "Interest Title",
    "jamboard.placeholderDesc": "Brief description",
    "jamboard.save": "Save",
    "jamboard.cancel": "Cancel",
    
    // Footer
    "footer.rights": "All rights reserved",
    "footer.contact": "Contact Us",
    "footer.privacy": "Privacy Policy",
    "footer.terms": "Terms of Service",
  },
  
  kn: {
    // Header
    "nav.home": "ಮುಖಪುಟ",
    "nav.about": "ನಮ್ಮ ಬಗ್ಗೆ",
    "nav.resources": "ಸಂಪನ್ಮೂಲಗಳು",
    "nav.opportunities": "ಅವಕಾಶಗಳು",
    "nav.profile": "ಪ್ರೊಫೈಲ್",
    
    // Landing Page
    "hero.title": "ನಿಮ್ಮ ವೃತ್ತಿಪರ ಮಾರ್ಗವನ್ನು ಕಂಡುಹಿಡಿಯಿರಿ",
    "hero.subtitle": "ನಿಮ್ಮ ಭವಿಷ್ಯಕ್ಕಾಗಿ ಮಾರ್ಗದರ್ಶನ, ಸಂಪನ್ಮೂಲಗಳು ಮತ್ತು ಅವಕಾಶಗಳು",
    "hero.cta": "ಪ್ರಾರಂಭಿಸಿ",
    
    // Success Stories
    "stories.title": "ಯಶಸ್ಸಿನ ಕಥೆಗಳು",
    "stories.subtitle": "ನಿಮ್ಮಂತೆಯೇ ಜನರಿಂದ ನಿಜವಾದ ಕಥೆಗಳು",
    "stories.readMore": "ಇನ್ನಷ್ಟು ಓದಿ",
    
    // JamBoard
    "jamboard.title": "ನಿಮ್ಮ ಆಸಕ್ತಿಗಳನ್ನು ವ್ಯಕ್ತಪಡಿಸಿ",
    "jamboard.subtitle": "ವೈಯಕ್ತಿಕ ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಲು ಕೌಶಲ್ಯಗಳು ಮತ್ತು ಆಸಕ್ತಿಗಳನ್ನು ಸೇರಿಸಿ",
    "jamboard.addInterest": "ಆಸಕ್ತಿ ಸೇರಿಸಿ",
    "jamboard.placeholderTitle": "ಆಸಕ್ತಿ ಶೀರ್ಷಿಕೆ",
    "jamboard.placeholderDesc": "ಸಂಕ್ಷಿಪ್ತ ವಿವರಣೆ",
    "jamboard.save": "ಉಳಿಸಿ",
    "jamboard.cancel": "ರದ್ದುಮಾಡಿ",
    
    // Footer
    "footer.rights": "ಎಲ್ಲಾ ಹಕ್ಕುಗಳನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ",
    "footer.contact": "ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ",
    "footer.privacy": "ಗೌಪ್ಯತಾ ನೀತಿ",
    "footer.terms": "ಸೇವಾ ನಿಯಮಗಳು",
  },
  
  hi: {
    // Header
    "nav.home": "होम",
    "nav.about": "हमारे बारे में",
    "nav.resources": "संसाधन",
    "nav.opportunities": "अवसर",
    "nav.profile": "प्रोफाइल",
    
    // Landing Page
    "hero.title": "अपना करियर पथ खोजें",
    "hero.subtitle": "आपके भविष्य के लिए मार्गदर्शन, संसाधन और अवसर",
    "hero.cta": "शुरू करें",
    
    // Success Stories
    "stories.title": "सफलता की कहानियाँ",
    "stories.subtitle": "आप जैसे लोगों से वास्तविक कहानियाँ जिन्होंने अपने लक्ष्य हासिल किए",
    "stories.readMore": "और पढ़ें",
    
    // JamBoard
    "jamboard.title": "अपनी रुचियों को व्यक्त करें",
    "jamboard.subtitle": "व्यक्तिगत सिफारिशें प्राप्त करने के लिए कौशल और रुचियां जोड़ें",
    "jamboard.addInterest": "रुचि जोड़ें",
    "jamboard.placeholderTitle": "रुचि शीर्षक",
    "jamboard.placeholderDesc": "संक्षिप्त विवरण",
    "jamboard.save": "सहेजें",
    "jamboard.cancel": "रद्द करें",
    
    // Footer
    "footer.rights": "सर्वाधिकार सुरक्षित",
    "footer.contact": "संपर्क करें",
    "footer.privacy": "गोपनीयता नीति",
    "footer.terms": "सेवा की शर्तें",
  },
};

export default translations;
